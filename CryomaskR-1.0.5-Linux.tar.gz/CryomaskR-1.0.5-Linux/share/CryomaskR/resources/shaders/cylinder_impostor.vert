#version 330 core

// GPU impostor rendering for bonds using ray-traced cylinders
// Generalized impostor cylinder technique
// Compatible with OpenGL 3.3 / macOS Core Profile

// Per-instance cylinder data
layout(location = 0) in vec3 cyl_start;     // Cylinder start position (world space)
layout(location = 1) in vec3 cyl_end;       // Cylinder end position (world space)
layout(location = 2) in float cyl_radius;   // Cylinder radius
layout(location = 3) in vec4 color_start;   // Color at start (for half-bond coloring)
layout(location = 4) in vec4 color_end;     // Color at end (for half-bond coloring)
layout(location = 5) in vec3 box_vertex;    // Bounding box vertex (8 vertices per cylinder)

// Uniforms
uniform mat4 projection;   // Projection matrix
uniform mat4 modelview;    // Model-view matrix

// Output to fragment shader
out vec3 frag_start_eye;      // Cylinder start in eye space
out vec3 frag_end_eye;        // Cylinder end in eye space
out float frag_radius;        // Cylinder radius
out vec4 frag_color_start;    // Start color
out vec4 frag_color_end;      // End color
out vec3 frag_pos_eye;        // Fragment position in eye space

void main() {
    // Transform cylinder endpoints to eye space
    vec4 start_eye = modelview * vec4(cyl_start, 1.0);
    vec4 end_eye = modelview * vec4(cyl_end, 1.0);

    frag_start_eye = start_eye.xyz;
    frag_end_eye = end_eye.xyz;
    frag_radius = cyl_radius;
    frag_color_start = color_start;
    frag_color_end = color_end;

    // Create oriented bounding box around cylinder
    // This creates a box that fully encloses the cylinder
    vec3 cyl_axis = cyl_end - cyl_start;
    float cyl_length = length(cyl_axis);
    vec3 axis_normalized = cyl_axis / cyl_length;

    // Find two perpendicular vectors to the cylinder axis
    // Use cross product with a non-parallel vector
    vec3 perp1;
    if (abs(axis_normalized.y) < 0.99) {
        perp1 = normalize(cross(axis_normalized, vec3(0.0, 1.0, 0.0)));
    } else {
        perp1 = normalize(cross(axis_normalized, vec3(1.0, 0.0, 0.0)));
    }
    vec3 perp2 = cross(axis_normalized, perp1);

    // Construct bounding box vertex position
    // box_vertex.x, box_vertex.y: radial offset (-1 to 1)
    // box_vertex.z: axial position (0 to 1 along cylinder)
    vec3 pos = cyl_start +
               axis_normalized * box_vertex.z * cyl_length +
               perp1 * box_vertex.x * cyl_radius * 1.2 +  // 1.2x oversized to ensure coverage
               perp2 * box_vertex.y * cyl_radius * 1.2;

    // Transform to eye space and project
    vec4 pos_eye = modelview * vec4(pos, 1.0);
    frag_pos_eye = pos_eye.xyz;
    gl_Position = projection * pos_eye;
}
