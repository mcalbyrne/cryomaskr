#version 410 core

layout(location = 0) in vec3 position;
layout(location = 1) in vec3 texCoord;

out vec3 fragTexCoord;
out vec3 fragWorldPos;
out vec3 viewRay;

uniform mat4 mvpMatrix;
uniform mat4 modelMatrix;
uniform mat4 viewMatrix;
uniform vec3 cameraPos;

void main() {
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    fragWorldPos = worldPos.xyz;
    fragTexCoord = texCoord;
    viewRay = worldPos.xyz - cameraPos;

    gl_Position = mvpMatrix * vec4(position, 1.0);
}