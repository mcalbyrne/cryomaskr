#version 410 core

// Simple fragment shader for lines

in vec3 fragColor;
out vec4 finalColor;

void main() {
    finalColor = vec4(fragColor, 1.0);
}
