#version 410 core

// Simple line rendering for wireframe bonds

layout(location = 0) in vec3 position;
layout(location = 1) in vec3 color;

out vec3 fragColor;

uniform mat4 mvpMatrix;

void main() {
    fragColor = color;
    gl_Position = mvpMatrix * vec4(position, 1.0);
}
