#version 410 core

// Fragment shader for dot surface with circular points

in vec3 fragColor;
in vec3 fragNormal;

out vec4 finalColor;

uniform vec3 lightDirection;
uniform float ambientStrength;
uniform float diffuseStrength;

void main() {
    // Make points circular
    vec2 coord = gl_PointCoord - vec2(0.5);
    if (length(coord) > 0.5) {
        discard;
    }

    // Simple lighting
    vec3 normal = normalize(fragNormal);
    vec3 ambient = ambientStrength * fragColor;
    float diff = max(dot(normal, normalize(lightDirection)), 0.0);
    vec3 diffuse = diffuseStrength * diff * fragColor;

    vec3 result = ambient + diffuse;
    finalColor = vec4(result, 1.0);
}
