#version 330 core

// Fragment shader for cylinder impostor rendering
// Performs ray-cylinder intersection and calculates lighting
// Compatible with OpenGL 3.3 / macOS Core Profile

// Input from vertex shader
in vec3 frag_start_eye;      // Cylinder start in eye space
in vec3 frag_end_eye;        // Cylinder end in eye space
in float frag_radius;        // Cylinder radius
in vec4 frag_color_start;    // Start color
in vec4 frag_color_end;      // End color
in vec3 frag_pos_eye;        // Fragment position in eye space

// Uniforms
uniform mat4 projection;     // Projection matrix
uniform vec3 light_dir;      // Light direction in eye space (normalized)

// Output
out vec4 fragColor;

void main() {
    // Ray from camera (at origin in eye space) through fragment
    vec3 ray_origin = vec3(0.0, 0.0, 0.0);
    vec3 ray_dir = normalize(frag_pos_eye);

    // Cylinder axis and parameters
    vec3 cyl_axis = frag_end_eye - frag_start_eye;
    float cyl_length = length(cyl_axis);
    vec3 cyl_dir = cyl_axis / cyl_length;

    // Ray-cylinder intersection (infinite cylinder)
    // Using geometric method: solve for ray parameter where distance to axis = radius
    vec3 oc = ray_origin - frag_start_eye;

    // Components perpendicular to cylinder axis
    vec3 ray_perp = ray_dir - cyl_dir * dot(ray_dir, cyl_dir);
    vec3 oc_perp = oc - cyl_dir * dot(oc, cyl_dir);

    // Quadratic equation: a*t^2 + b*t + c = 0
    float a = dot(ray_perp, ray_perp);
    float b = 2.0 * dot(ray_perp, oc_perp);
    float c = dot(oc_perp, oc_perp) - frag_radius * frag_radius;

    float discriminant = b * b - 4.0 * a * c;

    // Check if ray hits infinite cylinder
    if (discriminant < 0.0) {
        discard;  // Ray missed cylinder
    }

    // Find nearest intersection point
    float t = (-b - sqrt(discriminant)) / (2.0 * a);
    vec3 intersection = ray_origin + t * ray_dir;

    // Check if intersection is within cylinder caps
    vec3 to_intersection = intersection - frag_start_eye;
    float dist_along = dot(to_intersection, cyl_dir);

    if (dist_along < 0.0 || dist_along > cyl_length) {
        discard;  // Outside cylinder caps
    }

    // Calculate surface normal
    // Normal is perpendicular to cylinder axis, pointing radially outward
    vec3 closest_on_axis = frag_start_eye + cyl_dir * dist_along;
    vec3 normal = normalize(intersection - closest_on_axis);

    // Interpolate color along cylinder length (for half-bond coloring)
    float t_color = dist_along / cyl_length;
    vec4 base_color = mix(frag_color_start, frag_color_end, t_color);

    // Phong lighting model
    // Ambient component
    vec3 ambient = base_color.rgb * 0.3;

    // Diffuse component
    float diffuse_factor = max(dot(normal, -light_dir), 0.0);
    vec3 diffuse = base_color.rgb * 0.6 * diffuse_factor;

    // Specular component (glossy highlights)
    vec3 view_dir = -normalize(intersection);  // Direction to camera
    vec3 reflect_dir = reflect(light_dir, normal);
    float specular_factor = pow(max(dot(reflect_dir, view_dir), 0.0), 32.0);
    vec3 specular = vec3(0.4) * specular_factor;

    // Combine lighting components
    vec3 final_color = ambient + diffuse + specular;

    // Calculate correct fragment depth for z-sorting
    // Transform intersection point to clip space and compute depth
    vec4 clip_pos = projection * vec4(intersection, 1.0);
    float ndc_depth = clip_pos.z / clip_pos.w;
    gl_FragDepth = (ndc_depth + 1.0) * 0.5;  // Convert from [-1,1] to [0,1]

    // Output final color
    fragColor = vec4(final_color, base_color.a);
}
