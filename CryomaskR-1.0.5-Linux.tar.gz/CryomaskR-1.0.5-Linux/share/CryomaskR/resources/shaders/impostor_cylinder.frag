#version 410 core

// Fragment shader for impostor cylinders
// Ray-traces a cylinder per fragment

in vec3 fragColorStart;
in vec3 fragColorEnd;
in vec3 fragCylinderStart;   // View space
in vec3 fragCylinderEnd;     // View space
in vec3 fragCylinderAxis;    // Normalized cylinder axis
in float fragRadius;
in vec2 fragQuadCoord;

out vec4 finalColor;

uniform mat4 projMatrix;

// Multi-light system (3 lights: key, fill, rim)
uniform vec3 lightDirection[3];   // In view space
uniform vec3 lightColor[3];       // RGB color for each light
uniform float lightIntensity[3];  // Intensity multiplier for each light

// Material properties
uniform float ambientStrength;
uniform float diffuseStrength;
uniform float specularStrength;
uniform float shininess;

void main() {
    // Ray-cylinder intersection
    // Ray origin at fragment position, direction along -Z
    vec3 rayDir = vec3(0.0, 0.0, -1.0);

    // Reconstruct ray origin from billboard position
    vec3 center = (fragCylinderStart + fragCylinderEnd) * 0.5;
    vec3 cylinderVec = fragCylinderEnd - fragCylinderStart;
    float cylinderLength = length(cylinderVec);
    vec3 axis = normalize(cylinderVec);

    // Calculate perpendicular for ray origin
    vec3 viewDir = vec3(0.0, 0.0, -1.0);
    vec3 right = normalize(cross(cylinderVec, viewDir));
    if (length(right) < 0.001) {
        right = vec3(1.0, 0.0, 0.0);
    }

    vec3 rayOrigin = center + right * fragQuadCoord.x * fragRadius * 1.5 +
                     axis * fragQuadCoord.y * cylinderLength * 0.6;

    // Infinite cylinder intersection
    // Vector from ray origin to cylinder axis
    vec3 oc = rayOrigin - fragCylinderStart;

    // Project onto axis
    float projection = dot(oc, axis);
    vec3 closestOnAxis = fragCylinderStart + axis * projection;
    vec3 radiusVec = rayOrigin - closestOnAxis;

    // Ray-infinite cylinder intersection (2D problem in perpendicular plane)
    vec3 rayPerp = rayDir - axis * dot(rayDir, axis);
    vec3 ocPerp = oc - axis * dot(oc, axis);

    float a = dot(rayPerp, rayPerp);
    float b = 2.0 * dot(rayPerp, ocPerp);
    float c = dot(ocPerp, ocPerp) - fragRadius * fragRadius;

    float discriminant = b*b - 4.0*a*c;
    if (discriminant < 0.0) {
        discard;
    }

    // Find intersection
    float t = (-b - sqrt(discriminant)) / (2.0 * a);
    vec3 intersection = rayOrigin + t * rayDir;

    // Check if intersection is within cylinder caps
    vec3 toIntersection = intersection - fragCylinderStart;
    float axialDist = dot(toIntersection, axis);

    if (axialDist < 0.0 || axialDist > cylinderLength) {
        discard;
    }

    // Calculate normal (perpendicular to axis)
    vec3 pointOnAxis = fragCylinderStart + axis * axialDist;
    vec3 normal = normalize(intersection - pointOnAxis);

    // Interpolate color based on position along cylinder
    float t_color = axialDist / cylinderLength;
    vec3 color = mix(fragColorStart, fragColorEnd, t_color);

    // Multi-light Blinn-Phong lighting calculation
    vec3 viewDirNorm = normalize(-intersection);

    // Ambient component
    vec3 ambient = ambientStrength * color;

    // Accumulate diffuse and specular from all 3 lights
    vec3 diffuseAccum = vec3(0.0);
    vec3 specularAccum = vec3(0.0);

    // Loop over 3 lights (key, fill, rim)
    for (int i = 0; i < 3; i++) {
        vec3 L = normalize(lightDirection[i]);
        vec3 lightContrib = lightColor[i] * lightIntensity[i];

        // Diffuse (Lambertian)
        float NdotL = max(dot(normal, L), 0.0);
        diffuseAccum += NdotL * lightContrib * color;

        // Specular (Blinn-Phong using half-vector)
        vec3 H = normalize(L + viewDirNorm);
        float NdotH = max(dot(normal, H), 0.0);
        float spec = pow(NdotH, shininess);
        specularAccum += spec * lightContrib;
    }

    // Combine components
    vec3 result = ambient + diffuseStrength * diffuseAccum + specularStrength * specularAccum;

    // Update depth
    vec4 clipPos = projMatrix * vec4(intersection, 1.0);
    float ndcDepth = clipPos.z / clipPos.w;
    gl_FragDepth = (ndcDepth + 1.0) * 0.5;

    finalColor = vec4(result, 1.0);
}
