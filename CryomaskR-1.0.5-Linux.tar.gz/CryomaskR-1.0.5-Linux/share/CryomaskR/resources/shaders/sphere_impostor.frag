#version 330 core

// Fragment shader for sphere impostor rendering
// Performs ray-sphere intersection to render perfectly smooth spheres
// Calculates correct depth values for proper z-buffering

// Inputs from vertex shader
in vec3 frag_center_eye;   // Sphere center in eye space
in float frag_radius;      // Sphere radius
in vec4 frag_color;        // Sphere color
in vec2 frag_mapping;      // Quad coordinate (-1 to 1)

// Uniforms
uniform mat4 projMatrix;       // Projection matrix for depth calculation
uniform vec3 lightDirection;   // Light direction in eye space (should be normalized)

// Output
out vec4 fragColor;

void main() {
    // Ray-sphere intersection in eye space
    // In eye space, camera is at origin (0,0,0) looking down -Z axis
    vec3 ray_origin = vec3(0.0, 0.0, 0.0);

    // Ray target is the fragment position on the billboard quad
    vec3 ray_target = vec3(frag_mapping * frag_radius * 1.2, frag_center_eye.z);
    vec3 ray_dir = normalize(ray_target - ray_origin);

    // Vector from ray origin to sphere center
    vec3 oc = ray_origin - frag_center_eye;

    // Solve quadratic equation for ray-sphere intersection
    // t^2*dot(d,d) + 2*t*dot(oc,d) + dot(oc,oc) - r^2 = 0
    // Since ray_dir is normalized, dot(d,d) = 1
    float b = dot(oc, ray_dir);
    float c = dot(oc, oc) - frag_radius * frag_radius;
    float discriminant = b*b - c;

    // Discard fragment if ray misses the sphere
    if (discriminant < 0.0) {
        discard;
    }

    // Calculate intersection point (use nearest intersection for front face)
    float t = -b - sqrt(discriminant);
    vec3 intersection = ray_origin + t * ray_dir;

    // Calculate surface normal at intersection point
    // Normal points from sphere center to surface
    vec3 normal = normalize(intersection - frag_center_eye);

    // Phong lighting model
    // Ambient component
    float ambient = 0.3;

    // Diffuse component
    float diffuse_factor = max(dot(normal, -lightDirection), 0.0);
    float diffuse = 0.6 * diffuse_factor;

    // Specular component (Phong reflection)
    vec3 reflected = reflect(lightDirection, normal);
    vec3 view_dir = normalize(intersection);  // View direction towards camera at origin
    float specular_factor = pow(max(dot(reflected, -view_dir), 0.0), 32.0);
    float specular = 0.4 * specular_factor;

    // Combine lighting components
    vec3 color = frag_color.rgb * (ambient + diffuse) + vec3(specular);

    // Calculate correct depth value for z-buffering
    // Transform intersection point to clip space
    vec4 clip_pos = projMatrix * vec4(intersection, 1.0);

    // Convert to normalized device coordinates and then to depth range [0,1]
    float ndc_depth = clip_pos.z / clip_pos.w;
    gl_FragDepth = (ndc_depth + 1.0) * 0.5;

    // Output final color with alpha
    fragColor = vec4(color, frag_color.a);
}
