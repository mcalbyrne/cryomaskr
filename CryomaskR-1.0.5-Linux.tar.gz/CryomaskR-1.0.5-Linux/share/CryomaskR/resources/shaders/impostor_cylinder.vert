#version 410 core

// Impostor cylinder rendering using oriented billboards
// Generalized shader cylinder technique

layout(location = 0) in vec3 cylinder_start;   // Start position
layout(location = 1) in vec3 cylinder_end;     // End position
layout(location = 2) in float cylinder_radius; // Radius
layout(location = 3) in vec3 color_start;      // Color at start
layout(location = 4) in vec3 color_end;        // Color at end

out vec3 fragColorStart;
out vec3 fragColorEnd;
out vec3 fragCylinderStart;  // In view space
out vec3 fragCylinderEnd;    // In view space
out vec3 fragCylinderAxis;   // Cylinder axis in view space
out float fragRadius;
out vec2 fragQuadCoord;      // Billboard quad coordinates

uniform mat4 mvMatrix;       // Model-view matrix
uniform mat4 mvpMatrix;      // Model-view-projection matrix
uniform mat4 projMatrix;     // Projection matrix

// Quad vertices for oriented billboard
const vec2 quadVertices[4] = vec2[4](
    vec2(-1.0, -1.0),
    vec2( 1.0, -1.0),
    vec2(-1.0,  1.0),
    vec2( 1.0,  1.0)
);

void main() {
    // Transform cylinder endpoints to view space
    vec4 viewStart = mvMatrix * vec4(cylinder_start, 1.0);
    vec4 viewEnd = mvMatrix * vec4(cylinder_end, 1.0);

    fragCylinderStart = viewStart.xyz;
    fragCylinderEnd = viewEnd.xyz;
    fragCylinderAxis = normalize(viewEnd.xyz - viewStart.xyz);
    fragRadius = cylinder_radius;
    fragColorStart = color_start;
    fragColorEnd = color_end;

    // Get quad vertex
    int quadIndex = gl_VertexID % 4;
    vec2 quadCoord = quadVertices[quadIndex];
    fragQuadCoord = quadCoord;

    // Create oriented billboard
    // Calculate perpendicular vectors for billboard orientation
    vec3 cylinderVec = viewEnd.xyz - viewStart.xyz;
    float cylinderLength = length(cylinderVec);
    vec3 viewDir = vec3(0.0, 0.0, -1.0);  // Camera looks down -Z

    // Find perpendicular to both cylinder axis and view direction
    vec3 right = normalize(cross(cylinderVec, viewDir));
    if (length(right) < 0.001) {
        // Cylinder parallel to view, use up vector
        right = vec3(1.0, 0.0, 0.0);
    }
    vec3 up = normalize(cross(right, cylinderVec));

    // Position quad vertex
    vec3 center = (viewStart.xyz + viewEnd.xyz) * 0.5;
    vec3 offset = right * quadCoord.x * fragRadius * 1.5 +
                  normalize(cylinderVec) * quadCoord.y * cylinderLength * 0.6;

    vec4 viewPos = vec4(center + offset, 1.0);
    gl_Position = projMatrix * viewPos;
}
