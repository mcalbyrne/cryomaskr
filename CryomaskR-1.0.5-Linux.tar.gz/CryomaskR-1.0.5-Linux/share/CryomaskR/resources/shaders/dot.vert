#version 410 core

// Dot surface rendering using GL_POINTS

layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec3 color;

out vec3 fragColor;
out vec3 fragNormal;

uniform mat4 mvMatrix;
uniform mat4 mvpMatrix;
uniform mat3 normalMatrix;
uniform float pointSize;

void main() {
    fragColor = color;
    fragNormal = normalMatrix * normal;

    vec4 viewPos = mvMatrix * vec4(position, 1.0);
    gl_Position = mvpMatrix * vec4(position, 1.0);

    // Scale point size based on distance from camera
    float dist = length(viewPos.xyz);
    gl_PointSize = pointSize * (10.0 / dist);
    gl_PointSize = clamp(gl_PointSize, 1.0, 20.0);
}
