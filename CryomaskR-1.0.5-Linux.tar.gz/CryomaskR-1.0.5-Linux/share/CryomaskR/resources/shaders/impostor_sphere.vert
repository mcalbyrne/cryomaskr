#version 410 core

// Impostor sphere rendering using billboards
// Generalized techniques
// Each input point becomes a quad billboard facing the camera

layout(location = 0) in vec4 sphere_data;  // xyz = position, w = radius
layout(location = 1) in vec3 sphere_color; // rgb color

out vec3 fragColor;
out vec3 fragCenter;    // Sphere center in view space
out float fragRadius;   // Sphere radius
out vec2 fragQuadCoord; // Quad coordinates (-1 to 1)

uniform mat4 mvMatrix;      // Model-view matrix
uniform mat4 mvpMatrix;     // Model-view-projection matrix
uniform mat4 projMatrix;    // Projection matrix

// Quad vertices for billboard (will be set as constants)
const vec2 quadVertices[4] = vec2[4](
    vec2(-1.0, -1.0),
    vec2( 1.0, -1.0),
    vec2(-1.0,  1.0),
    vec2( 1.0,  1.0)
);

void main() {
    // Extract sphere parameters
    vec3 center = sphere_data.xyz;
    float radius = sphere_data.w;

    // Transform center to view space
    vec4 viewCenter = mvMatrix * vec4(center, 1.0);
    fragCenter = viewCenter.xyz;
    fragRadius = radius;
    fragColor = sphere_color;

    // Get quad vertex for this instance (use gl_VertexID % 4)
    int quadIndex = gl_VertexID % 4;
    vec2 quadCoord = quadVertices[quadIndex];
    fragQuadCoord = quadCoord;

    // Create billboard quad facing camera
    // Offset by radius in screen space to contain the sphere
    vec4 viewPos = viewCenter;
    viewPos.xy += quadCoord * radius * 1.5;  // 1.5 factor ensures sphere fits

    // Project to clip space
    gl_Position = projMatrix * viewPos;
}
