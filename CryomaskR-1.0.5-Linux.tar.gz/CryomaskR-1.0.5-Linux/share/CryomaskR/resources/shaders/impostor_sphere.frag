#version 410 core

// Fragment shader for impostor spheres
// Ray-traces a sphere per fragment for perfect spherical appearance

in vec3 fragColor;
in vec3 fragCenter;     // Sphere center in view space
in float fragRadius;    // Sphere radius
in vec2 fragQuadCoord;  // Quad coordinates (-1 to 1)

out vec4 finalColor;

uniform mat4 projMatrix;

// Multi-light system uniforms (3 lights: key, fill, rim)
uniform vec3 lightDirection[3];    // In view space
uniform vec3 lightColor[3];        // RGB color for each light
uniform float lightIntensity[3];   // Intensity multiplier for each light

// Material properties
uniform float ambientStrength;
uniform float diffuseStrength;
uniform float specularStrength;
uniform float shininess;

void main() {
    // Ray-sphere intersection in view space
    // Ray origin is at (fragQuadCoord * fragRadius * 1.5, 0) relative to sphere center
    // Ray direction is (0, 0, -1) in view space

    vec3 rayOrigin = fragCenter + vec3(fragQuadCoord * fragRadius * 1.5, 0.0);
    vec3 rayDir = vec3(0.0, 0.0, -1.0);  // Looking down -Z in view space

    // Sphere center relative to ray origin
    vec3 oc = rayOrigin - fragCenter;

    // Quadratic equation: t^2 + 2bt + c = 0
    float b = dot(oc, rayDir);
    float c = dot(oc, oc) - fragRadius * fragRadius;
    float discriminant = b*b - c;

    // Discard if ray misses sphere
    if (discriminant < 0.0) {
        discard;
    }

    // Find intersection point (use nearest intersection)
    float t = -b - sqrt(discriminant);
    vec3 intersection = rayOrigin + t * rayDir;

    // Calculate normal at intersection
    vec3 normal = normalize(intersection - fragCenter);
    vec3 viewDir = normalize(-intersection);  // View direction in view space

    // Ambient component
    vec3 ambient = ambientStrength * fragColor;

    // Accumulate diffuse and specular contributions from all lights
    vec3 diffuseAccum = vec3(0.0);
    vec3 specularAccum = vec3(0.0);

    // Loop over all 3 lights
    for (int i = 0; i < 3; i++) {
        vec3 L = normalize(lightDirection[i]);
        vec3 lightContrib = lightColor[i] * lightIntensity[i];

        // Diffuse (Lambertian)
        float NdotL = max(dot(normal, L), 0.0);
        diffuseAccum += NdotL * lightContrib * fragColor;

        // Specular (Blinn-Phong using half-vector)
        vec3 H = normalize(L + viewDir);
        float NdotH = max(dot(normal, H), 0.0);
        float spec = pow(NdotH, shininess);
        specularAccum += spec * lightContrib;
    }

    // Combine components with strength multipliers
    vec3 result = ambient + diffuseStrength * diffuseAccum + specularStrength * specularAccum;

    // Update depth buffer correctly
    // Transform intersection point to clip space and calculate depth
    vec4 clipPos = projMatrix * vec4(intersection, 1.0);
    float ndcDepth = clipPos.z / clipPos.w;
    gl_FragDepth = (ndcDepth + 1.0) * 0.5;  // Convert to [0,1]

    finalColor = vec4(result, 1.0);
}
