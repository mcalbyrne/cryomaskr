#version 410 core

in vec3 fragTexCoord;
in vec3 fragWorldPos;
in vec3 viewRay;

out vec4 fragColor;

uniform sampler3D volumeTexture;
uniform float contourLevel;
uniform float opacity;
uniform vec3 volumeDimensions;

// Lighting
uniform vec3 lightDirection;
uniform float ambientStrength;
uniform float diffuseStrength;
uniform float specularStrength;
uniform float shininess;

// Display options
uniform bool useGradientShading;
uniform bool showWireframe;
uniform vec4 clipPlane;
uniform bool enableClipping;

// Calculate gradient using central differences
vec3 calculateGradient(vec3 texCoord) {
    vec3 step = 1.0 / volumeDimensions;

    float dx = texture(volumeTexture, texCoord + vec3(step.x, 0.0, 0.0)).r -
               texture(volumeTexture, texCoord - vec3(step.x, 0.0, 0.0)).r;
    float dy = texture(volumeTexture, texCoord + vec3(0.0, step.y, 0.0)).r -
               texture(volumeTexture, texCoord - vec3(0.0, step.y, 0.0)).r;
    float dz = texture(volumeTexture, texCoord + vec3(0.0, 0.0, step.z)).r -
               texture(volumeTexture, texCoord - vec3(0.0, 0.0, step.z)).r;

    return normalize(vec3(dx, dy, dz));
}

void main() {
    // Clip if enabled
    if (enableClipping && dot(vec4(fragWorldPos, 1.0), clipPlane) < 0.0) {
        discard;
    }

    // Sample volume
    float density = texture(volumeTexture, fragTexCoord).r;

    // Apply contour level threshold
    if (density < contourLevel) {
        discard;
    }

    // Base color (can be modified based on density)
    vec3 baseColor = vec3(0.7, 0.7, 0.8);

    // Apply gradient shading if enabled
    vec3 finalColor = baseColor;
    if (useGradientShading) {
        vec3 gradient = calculateGradient(fragTexCoord);

        // Ambient
        vec3 ambient = ambientStrength * baseColor;

        // Diffuse
        float diff = max(dot(gradient, normalize(lightDirection)), 0.0);
        vec3 diffuse = diffuseStrength * diff * baseColor;

        // Specular
        vec3 viewDir = normalize(-viewRay);
        vec3 reflectDir = reflect(-normalize(lightDirection), gradient);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), shininess);
        vec3 specular = specularStrength * spec * vec3(1.0);

        finalColor = ambient + diffuse + specular;
    }

    // Apply opacity based on density
    float alpha = opacity * smoothstep(contourLevel, contourLevel + 0.1, density);

    // Wireframe mode
    if (showWireframe) {
        // Create wireframe effect at voxel boundaries
        vec3 grid = abs(fract(fragTexCoord * volumeDimensions - 0.5) - 0.5);
        float line = smoothstep(0.0, 0.02, min(min(grid.x, grid.y), grid.z));
        finalColor = mix(vec3(1.0), finalColor, line);
    }

    fragColor = vec4(finalColor, alpha);
}