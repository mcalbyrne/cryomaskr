#version 330 core

// Sphere impostor rendering using billboard quads with ray-tracing
// High-performance molecular visualization technique (generalized)
// Renders perfectly smooth spheres using only 2 triangles per atom

// Per-instance data (one set per sphere)
layout(location = 0) in vec3 sphere_center;  // xyz position of sphere center
layout(location = 1) in float sphere_radius; // radius of the sphere
layout(location = 2) in vec4 sphere_color;   // RGBA color

// Per-vertex data (quad corner vertices: 4 vertices per instance)
layout(location = 3) in vec2 quad_vertex;    // (-1,-1), (1,-1), (-1,1), (1,1)

// Uniforms
uniform mat4 projMatrix;   // Projection matrix
uniform mat4 mvMatrix;     // Model-view matrix
uniform mat4 mvpMatrix;    // Model-view-projection matrix

// Outputs to fragment shader
out vec3 frag_center_eye;   // Sphere center in eye/view space
out float frag_radius;      // Sphere radius
out vec4 frag_color;        // Sphere color
out vec2 frag_mapping;      // Quad coordinate (-1 to 1)

void main() {
    // Transform sphere center to eye/view space
    vec4 center_eye = mvMatrix * vec4(sphere_center, 1.0);
    frag_center_eye = center_eye.xyz;
    frag_radius = sphere_radius;
    frag_color = sphere_color;
    frag_mapping = quad_vertex;

    // Create billboard quad facing camera in eye space
    // The quad is centered at the sphere center and sized to contain the sphere
    vec4 corner = center_eye;
    corner.xy += quad_vertex * sphere_radius * 1.2;  // 1.2 factor ensures full coverage

    // Project to clip space
    gl_Position = projMatrix * corner;
}
